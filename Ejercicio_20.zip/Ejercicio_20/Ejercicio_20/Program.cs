﻿using System;
using System.Text;
using System.Collections;
using System.Linq;
using System.Threading.Tasks;
namespace Ejercicio_20
{
    class Program
    {
        static void Main(string[] args)
        {
            //inicializo las variables de tipo int y de tipo double para datos numericos
            int hora1, minuto1, segundo1, hora2, minuto2, segundo2;
            double difhora, difminuto, difsegundo, resul;

            Console.WriteLine("Ingrese una hora inicial AM: ");
            hora1 = int.Parse(Console.ReadLine());
            Console.WriteLine("");
            Console.WriteLine("Ingrese los minutos de la hora inicial: ");
            minuto1 = int.Parse(Console.ReadLine());
            Console.WriteLine("");
            Console.WriteLine("Ingrese los segundos de la hora inicial:");
            segundo1 = int.Parse(Console.ReadLine());

            Console.WriteLine("Ingrese una hora final PM: ");
            hora2 = int.Parse(Console.ReadLine());
            Console.WriteLine("");
            Console.WriteLine("Ingrese los minutos de la hora final: ");
            minuto2 = int.Parse(Console.ReadLine());
            Console.WriteLine("");
            Console.WriteLine("Ingrese los segundos de la hora final:");
            segundo2 = int.Parse(Console.ReadLine());

            difhora = hora1 - hora2;
            difminuto = minuto1 - minuto2;
            difsegundo = segundo1 - segundo2;

            Console.WriteLine("La diferencia entre horas es: "+difhora+" , en minutos es: "+difminuto+" , en segundos es: "+difsegundo);
            Console.ReadKey();
        }
    }

}