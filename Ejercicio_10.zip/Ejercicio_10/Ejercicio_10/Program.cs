﻿using System;

public class test
{
    static void Main(string[] args)
    {
        // array de numero ordenado ascendente
        int[] intArray = new int[10] { 7, 10, 2, 5, 23, 14, 67, 0, 9, 14 };
        Console.WriteLine("Datos ordenados ascendentemente");
        Array.Sort(intArray);
        foreach (int i in intArray)
        {
            Console.Write(i + " ");
        }
        Console.Write("\n");



        // ordenamos el array descendente
        Console.WriteLine("Datos ordenados descendentemente");
        Array.Reverse(intArray);
        foreach (int s in intArray)
        {
            Console.Write(s + " ");
        }
        Console.Write("\n");
    }
}

