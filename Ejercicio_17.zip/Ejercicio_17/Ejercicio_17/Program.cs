﻿using System;

namespace Ejercicio_17
{
    class Program
    {
        static void Main(string[] args)
        {
            bool salir = false;
            while (!salir)
            {
                try
                {
                    double moneda, peso=0, dolar=0, euro, libra, yen, total;
                   

                    Console.WriteLine("--------MENÚ DE OPCIONES---------");
                    Console.WriteLine("");
                    Console.WriteLine("1. Conversión de pesos a dólares");
                    Console.WriteLine("");
                    Console.WriteLine("2. Conversión de pesos a euros");
                    Console.WriteLine("");
                    Console.WriteLine("3. Conversión de pesos a libras esterlina");
                    Console.WriteLine("");
                    Console.WriteLine("4. Conversión de pesos a yenes");
                    Console.WriteLine("");
                    Console.WriteLine("5. Salir");
                    int opcion = Convert.ToInt32(Console.ReadLine());
                    switch (opcion)
                    {

                        case 1:
                            Console.WriteLine("Ingresa valor en pesos para pasar a dólares: ");
                            Console.WriteLine("");
                            moneda = double.Parse(Console.ReadLine());
                            total = 0.00026*moneda;
                            Console.WriteLine(moneda + " pesos es equivalente a: " + total+" dólares");
                            break;

                        case 2: 
                            Console.WriteLine("Ingresa valor en pesos para pasar a euros: ");
                            Console.WriteLine("");
                            moneda = double.Parse(Console.ReadLine());
                            total = 0.00022 * moneda;
                            Console.WriteLine(moneda + " pesos es equivalente a: " + total+" euros");
                            break;


                        case 3:
                            Console.WriteLine("Ingresa valor en pesos para pasar a libra esterlina: ");
                            Console.WriteLine("");
                            moneda = double.Parse(Console.ReadLine());
                            total = 0.00019 * moneda;
                            Console.WriteLine(moneda + " pesos es equivalente a: " + total + " libra esterlina");
                            break;


                        case 4:
                            Console.WriteLine("Ingresa valor en pesos para pasar a yen: ");
                            Console.WriteLine("");
                            moneda = double.Parse(Console.ReadLine());
                            total = 0.029 * moneda;
                            Console.WriteLine(moneda + " pesos es equivalente a: " + total + " yen");
                            break;

                        case 5:
                            Console.WriteLine("Salir");
                            salir = true;
                            break;

                    }
                }
                catch (FormatException e)
                {
                    Console.WriteLine(e.Message);
                }
            }
        }
    }
}
