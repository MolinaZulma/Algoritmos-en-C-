﻿using System;

namespace Ejercicio_8
{
    class Program
    {
        static void Main(string[] args)

        {
            int val = 0;
            
            Console.WriteLine("----------------SISTEMA DE PARQUEADERO------------------");
            Console.WriteLine("");
            do
            {
                try
                {
                    double min = 0;
                    do
                    {
                        Console.WriteLine("Ingrese los minutos de parqueadero: ");
                        min = double.Parse(Console.ReadLine());

                        if (min <= 0)
                        {
                            Console.WriteLine("Solo datos mayores que cero");
                        }
                    } while (min <= 0);
                    double valor = 0;
                    if (min <= 60)
                    {
                        valor = 1000;
                    }
                    else
                    {
                        min = min - 60;
                        double min_extra = 0;
                        if (min > 15)
                        {
                            min = min / 15;
                            min_extra = Math.Ceiling(min);

                        }
                        else { min_extra = 1; }
                        valor = 0.50 + (min_extra * 0.10);
                    }
                    Console.WriteLine("Total a pagar: ");
                    Console.ReadLine();
                }
                catch (Exception)
                {
                    val = 1;
                    Console.WriteLine("Ingreso incorrecto");

                }
            } while (val == 1);
            
        }

    }
}

