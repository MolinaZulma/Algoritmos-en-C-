﻿using System;

namespace Ejercicio_19
{
    class Program
    {
        static void Main(string[] args)
        {
            string nom;
            double indice;

            Console.WriteLine("Ingrese nombre de la persona: ");
            nom = Console.ReadLine();
            Console.WriteLine("");
            Console.WriteLine("Ingrese indice de masa corporal: ");
            indice = double.Parse(Console.ReadLine());

            //Aquí inicializo las condiciones que me permiten evaluar el valor ingresado por teclado.
            //Al ingresar valor por teclado no se debe usar punto sino coma
            if (indice<16){Console.WriteLine(nom + " su indice de masa corporal es: "+indice+" su delgadez es Severa");}
            else
            if (indice>=16 & indice<=16.99) { Console.WriteLine(nom + " su indice de masa corporal es: "+ indice+" delgadez es Moderada"); }
            else
            if (indice>=17 & indice<=18.49) { Console.WriteLine(nom + " su indice de masa corporal es: " + indice + "delgadez es Leve"); }
            else
            if (indice>=18.5 & indice<=24.99) { Console.WriteLine(nom + "su indice de masa corporal es: "+ indice+ " es Normal"); }
            else
            if (indice>=25 & indice<=29.9) { Console.WriteLine(nom + " su indice de masa corporal es: "+ indice+" tiene Sobrepeso, Preobeso"); }
            else
            if (indice >= 30 & indice <= 34.99) { Console.WriteLine(nom + " su indice de masa corporal es: "+ indice+" tiene Obesidad Leve"); }
            else
            if (indice >= 35 & indice <= 39.99) { Console.WriteLine(nom + " su indice de masa corporal es: "+ indice+ " tiene Obesidad Media");}
            else
            if (indice > 40) { Console.WriteLine(nom + " su indice de masa corporal es: " + indice+ " tiene Obesidad Morbida"); }
        }
    }
}
