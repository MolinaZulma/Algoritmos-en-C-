﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ejercicio_3
{
    class Program
    {
        static void Main(string[] args)
        {
            double suma, prom1, prom2, prom3, prom4, prom5, total;
            string alumno;
            int lenguaje, matematicas, cien_sociales, cien_naturales, idiomas, admi;

            Console.WriteLine("*******************PROMEDIO PONDERADO EXAMEN ICFES********************");
            Console.WriteLine(" ");
            Console.WriteLine("Los puntajes que ingrese al sistema deben ser valores minimos de 1 y máximos de 100");
            Console.WriteLine(" ");
            Console.Write("Ingrese nombre del estudiante: "); alumno = Console.ReadLine();
            Console.Write("Ingrese puntaje del area de Lenguaje: ");
            lenguaje = int.Parse(Console.ReadLine());
            Console.Write("Ingrese puntaje del area de Matemáticas: ");
            matematicas = int.Parse(Console.ReadLine());
            Console.Write("Ingrese puntaje del area de Ciencias Sociales: ");
            cien_sociales = int.Parse(Console.ReadLine());
            Console.Write("Ingrese puntaje del area de Ciencias Naturales: ");
            cien_naturales = int.Parse(Console.ReadLine());
            Console.Write("Ingrese puntaje del area de Idiomas: ");
            idiomas = int.Parse(Console.ReadLine());
            Console.Write("Ingrese puntaje obtenido en el examen de admisión: ");
            admi = int.Parse(Console.ReadLine());

            //Calculo del promedio en porcentaje de cada área
            {
                prom1 = ((lenguaje * 25) / 100);
                prom2 = ((matematicas * 25) / 100);
                prom3 = ((cien_sociales * 15) / 100);
                prom4 = ((cien_naturales * 20) / 100);
                prom5 = ((idiomas * 15) / 100);
                suma = (prom1 + prom2 + prom3 + prom4 + prom5);
                total = admi;
            }
            if (total > 84 & suma > 70)
            {
                Console.WriteLine("Usted ha sido admitido");
            }
            if (total < 85 & suma < 69)
            {
                Console.WriteLine("Usted no es admitido");
            }

        }
     }   
 }
