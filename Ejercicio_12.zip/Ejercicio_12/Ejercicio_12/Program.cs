﻿using System;

namespace Ejercicio_12
{
    class Program
    {
        static void Main(string[] args)
        {
            
            int dia, mes; 
            Console.WriteLine("Ingresa el mes en números: ");
            mes = int.Parse(Console.ReadLine());
            Console.WriteLine("Ingresa la fecha del día: ");
            dia = int.Parse(Console.ReadLine());
            
            if (mes==03&dia==21||mes==04||mes==05||mes==06&dia<=20)
            {
                Console.WriteLine("Es Primavera");
            }
            else
            if (mes==06&dia<=21||mes==07||mes==08||mes==09&dia<=20)
            {
                Console.WriteLine("Es Verano");
            }
            else
            if (mes==09&dia<=21||mes==10||mes==11||mes==12&dia<=20)
            {
                Console.WriteLine("Es Otoño");
            }
            else
                if (mes==12&dia<=21||mes==01||mes==02||mes==03&dia<=20)
            {
                Console.WriteLine("Es Invierno");
            }
        }
    }
}
