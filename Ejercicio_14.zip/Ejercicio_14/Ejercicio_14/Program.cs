﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Linq;

namespace Ejercicio_14
{
    class Program
    {
        static void Main(string[] args)
        {
            string nom;
            double nota;
            Console.WriteLine("");
            Console.WriteLine("---------SISTEMA DE CALIFICACIONES DE 0 A 100----------");
            Console.WriteLine("");
            Console.WriteLine("");
            Console.WriteLine("Ingrese nombre del alumno: ");
            nom = Console.ReadLine();
            Console.WriteLine("");
            Console.WriteLine("Ingrese nota del alumno: ");
            nota = double.Parse(Console.ReadLine());
            
            if (nota >= 90 & nota<100) { Console.WriteLine(nom + " es Muy Bueno"); }
            else
            if (nota >= 80) { Console.WriteLine(nom + " es Bueno");}
            else
            if (nota >= 70) { Console.WriteLine(nom + " es Regular");}
            else
            if (nota >= 60) { Console.WriteLine(nom + " es Malo");}
            else
            if (nota >= 0) { Console.WriteLine(nom + " es Reprobado");}
        }
    }
}
