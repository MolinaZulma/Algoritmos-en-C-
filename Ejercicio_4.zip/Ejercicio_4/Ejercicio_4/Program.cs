﻿using System;
using System.Text;
using System.Threading.Tasks;
using System.Linq;

namespace Ejercicio_4
{
    class Program
    {
        static void Main(string[] args)
        {
            int acu = 0, numero;
            int contadoracu = 0;

            Console.WriteLine("Ingresa un número: "); numero = int.Parse(Console.ReadLine());

            do
            {
                Console.WriteLine("Los multiplos son: {0}", acu);
                acu = acu + numero;
                contadoracu = contadoracu + 1;
            }
            while (acu < 40); //Hasta que llegue a 40
            Console.WriteLine("El número de multiplos encontrados son: {0}", contadoracu);
            

        }
    }
}
