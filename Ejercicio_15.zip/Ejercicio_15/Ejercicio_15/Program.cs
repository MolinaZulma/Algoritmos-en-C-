﻿using System;

namespace Ejercicio_15
{
    class Program
    {
        static void Main(string[] args)
        {
            double pago, compra, des;
            int bol;
            Random rand = new Random();

            Console.WriteLine("Registre el valor de la compra: ");
            compra = double.Parse(Console.ReadLine());
            Console.WriteLine("");
            des = 0;
            bol = rand.Next(4);


            if(bol==0)
            {
                des = compra * 0.0;
                Console.WriteLine("Su compra es de: " + compra + " y no tiene descuento, porque sacaste la bolita BLANCA");
            }
            if(bol==1)
            {
                des = compra * 0.2;
                Console.WriteLine("Su compra es de: " + compra + ", la bolita sacada es VERDE");
            }
            if(bol==2)
            {
                des = compra * 0.25;
                Console.WriteLine("Su compra es de: " + compra + ", la bolita sacada es AMARILLA");
            }
            if (bol == 3)
            {
                des = compra * 0.3;
                Console.WriteLine("Su compra es de: " + compra + ", la bolita sacada es NEGRA");
            }

            pago = compra - des;
            Console.WriteLine("La bolita es: " + bol);
            Console.WriteLine("El total a pagar es: " + pago+" , el descuento es de: "+des);
            Console.WriteLine("");
         
        }
    }
}
