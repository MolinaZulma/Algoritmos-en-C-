﻿using System;
using System.Text;
using System.Windows;
using System.IO;


namespace Ejercicio_16
{
    class Program
    {
        static void Main(string[] args)
        {
                int j;
                char i;
                string frase, letraR;
                int recta = 0;
                int curva = 0;
                int curva_recta = 0;
                int espacio = 0;

                Console.WriteLine("Ingresa una frase en MAYUSCULAS: ");
                frase = Console.ReadLine();
                letraR = Console.ReadLine();

                for (j = 0; j < frase.Length; j++)
                {
                    i = frase[j];
                    int l = char.ToLower(i);
                    if ((l == 'A') & (l == 'E') & (l == 'F') & (l == 'H') & (l == 'I') & (l == 'K') & (l == 'L') & (l == 'M') & (l == 'N') & (l == 'T') & (l == 'V') & (l == 'W') & (l == 'X') & (l == 'Y') & (l == 'Z'))
                    {
                        recta++;

                    }

                    if ((l == 'C') & (l == 'O') & (l == 'S') & (l == 'Q'))
                    {
                        curva++;

                    }

                    if ((l == 'B') & (l == 'D') & (l == 'G') & (l == 'J') & (l == 'P') & (l == 'R') & (l == 'U'))
                    {
                        curva_recta++;

                    }

                    if (l == ' ')
                    {
                        espacio++;

                    }
                }
                Console.WriteLine("");
                Console.WriteLine("La frase tiene " + recta++ + " rectas");
                Console.WriteLine("La frase tiene " + curva + " curvas");
                Console.WriteLine("La frase tiene " + curva_recta + " curvas y rectas");
                Console.WriteLine("La frase tiene " + espacio + " espacios");
                Console.WriteLine("La frase tiene " + frase.Length + " caracteres");
            }
        }
    }