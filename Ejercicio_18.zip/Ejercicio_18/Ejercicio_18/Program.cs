﻿using System;
using System.Text;
using System.Collections;
using System.Linq;

namespace Ejercicio_18
{
    class Program
    {
        static void Main(string[] args)
        {
            bool salir = false;
            while (!salir)
            {
                try
                {
                    double mtr=0, cmt=0, pies=0, yar=0, pul=0 ;

                    Console.WriteLine("--------MENÚ DE OPCIONES---------");
                    Console.WriteLine("");
                    Console.WriteLine("1. Conversión de metros a centimetros");
                    Console.WriteLine("");
                    Console.WriteLine("2. Conversión de centimetros a pulgadas");
                    Console.WriteLine("");
                    Console.WriteLine("3. Conversión de pulgadas a pies");
                    Console.WriteLine("");
                    Console.WriteLine("4. Conversión de pies a yardas");
                    Console.WriteLine("");
                    Console.WriteLine("5. Salir");
                    int opcion = Convert.ToInt32(Console.ReadLine());
                    switch (opcion)
                    {

                        case 1:
                            Console.WriteLine("Ingresa un valor para pasar de metros a centimetros: ");
                            Console.WriteLine("");
                            mtr = double.Parse(Console.ReadLine());
                            cmt = mtr * 100;
                            Console.WriteLine("La medida en centimetros es: "+cmt);
                            Console.WriteLine("");
                            break;

                        case 2:
                            Console.WriteLine("Ingresa un valor para pasar de centimetros a pulgadas: ");
                            Console.WriteLine("");
                            cmt = double.Parse(Console.ReadLine());
                            pul = cmt / 2.54;
                            Console.WriteLine("La medida en pulgadas es: " + pul);
                            Console.WriteLine("");
                            break;

                        case 3:
                            Console.WriteLine("Ingresa un valor para pasar de pulgadas a pies: ");
                            Console.WriteLine("");
                            pul = double.Parse(Console.ReadLine());
                            pies = pul / 12;
                            Console.WriteLine("La medida en pies es: " + pies);
                            Console.WriteLine("");
                            break;

                        case 4:
                            Console.WriteLine("Ingresa un valor para pasar de pies a yardas: ");
                            Console.WriteLine("");
                            pies = double.Parse(Console.ReadLine());
                            yar = pies / 3;
                            Console.WriteLine("La medida en yardas es: " + yar);
                            Console.WriteLine("");
                            break;

                        case 5:
                            Console.WriteLine("Salir");
                            salir = true;
                            break;

                    }
                }
                catch (FormatException e)
                {
                    Console.WriteLine(e.Message);
                }
            }
        }
    }
}
