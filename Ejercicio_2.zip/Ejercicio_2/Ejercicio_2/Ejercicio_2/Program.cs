﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ejercicio_2
{
    class Program
    {
        static void Main(string[] args)
        {
            int lado1, lado2, lado3;
            string linea;
            Console.Write("Ingrese un dato numérico: "); linea = Console.ReadLine();
            lado1 = int.Parse(linea);
            Console.Write("Ingrese un segundo dato numérico: "); linea = Console.ReadLine();
            lado2 = int.Parse(linea);
            Console.Write("Ingrese un tercer dato numérico: "); linea = Console.ReadLine();
            lado3 = int.Parse(linea);

            if (lado1 == lado2 & lado2 == lado3)
                    {
                Console.WriteLine("Con estos datos se forma un triangulo equilatero, porque todos sus lados son iguales");
            }
            else
            {
                if (lado1 != lado2 & lado1 != lado3 & lado2 != lado3)
                {
                    Console.WriteLine("Con estos datos se forma un triangulo escaleno, porque todos sus lados son distintos");
                }
                else
                {
                    Console.WriteLine("Con estos datos se forma un triangulo isosceles, porque tiene dos lados iguales");
                }
            }
            Console.WriteLine("Oprime una tecla para salir: "); Console.ReadLine();

        }
    }
}
