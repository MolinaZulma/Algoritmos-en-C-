﻿using System;

namespace Ejercicio_7
{
    class Program
    {
        static void Main(string[] args)
        {
            //declaración de variables de tipo double y string para ingresar el nombre
            double vh, ht, salario;
            string nombre;

            Console.WriteLine("Ingrese nombre del trabajador");
            Console.WriteLine("");
            nombre = Console.ReadLine();
            Console.Write("Ingresa el costo de la hora: ");
            Console.WriteLine("");
            vh = double.Parse(Console.ReadLine());
            Console.Write("Ingresa la cantidad de horas trabajadas: ");
            Console.WriteLine("");
            ht = double.Parse(Console.ReadLine());

            //Calculo del salario segun la cantidad de horas trabajadas
            salario = ht * vh;

            //Condicionales que permiten realizar el calculo segun la cantidad de horas trabaja
            if (ht > 40)
                salario = salario + (ht - 40) * vh;
            if (ht > 48)
                salario = salario + (ht - 48) * vh;
            Console.WriteLine(nombre + " trabajó: " + ht + " horas, y su salario es: " + salario + " pesos");

            Console.ReadKey();
        }
    }
}