﻿using System;

namespace Ejercicio_11
{
	class Program
	{
		static void Main(string[] args)
		{
			float x;
			float y;
			
			Console.Write("Ingresa un número del plano cartesiano en X: ");
			x = float.Parse(Console.ReadLine());
			Console.Write("Ingresa un número del plano cartesiano en Y: ");
			y = float.Parse(Console.ReadLine());
			

			Console.WriteLine();
			
			if (x>=0){Console.Write("La coordenada se encuentra en el lado positivo de X"); Console.WriteLine(""); }
			
			else
            {
				Console.WriteLine("La coordenada se encuentra en el lado negativo de -X"); Console.WriteLine("");
			}
			
			if (y>=0){Console.Write("La coordenada se encuentra en el lado positivo de Y"); Console.WriteLine(""); }
			else
            {
				Console.WriteLine("La coordenada se encuentra en el lado negativo de -Y"); Console.WriteLine("");
			}
			
			
		}
	}
}
