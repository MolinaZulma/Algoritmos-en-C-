﻿using System;

namespace Ejercicio_13
{
    class Program
    {
        static void Main(string[] args)
        {
            bool salir = false;
            while(!salir)
            {
                try
                {
                    double altura, bas, resultado, radio, lado1, lado2;

                    Console.WriteLine("--------MENÚ DE OPCIONES---------");
                    Console.WriteLine("");
                    Console.WriteLine("1. Área de un triángulo: ");
                    Console.WriteLine("");
                    Console.WriteLine("2. Área de un círculo: ");
                    Console.WriteLine("");
                    Console.WriteLine("3. Área de un rectángulo: ");
                    Console.WriteLine("");
                    Console.WriteLine("4. Área de un cuadrado: ");
                    Console.WriteLine("");
                    Console.WriteLine("5. Salir");
                    int opcion = Convert.ToInt32(Console.ReadLine());
                    switch(opcion)
                    {

                        case 1:
                            Console.WriteLine("Calcula el área de un triángulo");
                            Console.WriteLine("");
                            Console.WriteLine("Ingresa la base del triángulo: ");
                            bas = double.Parse(Console.ReadLine());
                            Console.WriteLine("");
                            Console.WriteLine("Ingresa la altura del triángulo: ");
                            altura= double.Parse(Console.ReadLine());
                            resultado = (bas * altura) / 2;
                            Console.WriteLine("El área del triángulo es: "+resultado);
                            break;

                        case 2:
                            Console.WriteLine("Calcula el área de un círculo");
                            Console.WriteLine("");
                            Console.WriteLine("Ingresa el radio del círculo: ");
                            Console.WriteLine("");
                            radio = double.Parse(Console.ReadLine());
                            resultado = 3.1416 * Math.Pow(radio, 2);
                            Console.WriteLine("El área del círculo es: "+resultado);
                            break;

                        case 3:
                            Console.WriteLine("Calcular el área de un rectángulo");
                            Console.WriteLine("");
                            Console.WriteLine("Ingresa la base del rectángulo: ");
                            bas = double.Parse(Console.ReadLine());
                            Console.WriteLine("");
                            Console.WriteLine("Ingresa la altura del rectángulo: ");
                            altura = double.Parse(Console.ReadLine());
                            resultado = bas * altura;
                            Console.WriteLine("");
                            Console.WriteLine("El área del rectángulo es: "+resultado);
                            break;

                        case 4:
                            Console.WriteLine("Calcular el área de un cuadrado");
                            Console.WriteLine("");
                            Console.WriteLine("Ingresa el lado del cuadrado: ");
                            lado1 = double.Parse(Console.ReadLine());
                            Console.WriteLine("");
                            Console.WriteLine("Ingresa el siguiente lado del cuadrado: ");
                            lado2 = double.Parse(Console.ReadLine());
                            Console.WriteLine("");
                            resultado = lado1 * lado2;
                            Console.WriteLine("El área del cuadrado es: "+resultado);
                            break;
                        case 5:
                            Console.WriteLine("Salir");
                            salir = true;
                            break;

                    }
                }
                catch (FormatException e)
                {
                    Console.WriteLine(e.Message);
                }
            }
        }
    }
}
