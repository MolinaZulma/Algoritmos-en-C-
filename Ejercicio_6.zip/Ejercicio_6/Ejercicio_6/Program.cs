﻿using System;

namespace Ejercicio_6
{
    class Program
    {
        static void Main(string[] args)
        {
            double lado1, lado2, resul;
            int op;

            Console.WriteLine("++++++++++CALCULO DE ANGULOS++++++++++++");
            Console.WriteLine("");
            Console.WriteLine("Ingrese un lado del triángulo: ");
            lado1 = double.Parse(Console.ReadLine());
            Console.WriteLine("");
            Console.WriteLine("Ingrese otro lado del triángulo: ");
            lado2 = double.Parse(Console.ReadLine());
            Console.WriteLine("");
            Console.WriteLine("Escoge que lado vas a calcular");
            Console.WriteLine("\n1.- \u00C1ngulo");
            Console.WriteLine("\n2.- Hipotenusa");
            Console.WriteLine("\n3.- Cateto opuesto");
            Console.WriteLine("\n4.- Cateto adyacente");
            Console.Write("\n: ");
            do
            {
                op = int.Parse(Console.ReadLine());
                if (op < 1 || op > 4)
                    Console.Write("Valor incorrecto. Ingresa nuevamente.: ");
            } while (op < 1 || op > 4);
            resul = 0;
            if (op == 1 && lado2 != 0)
                resul = Math.Atan(lado1 / lado2) * 180.0 / Math.PI;
            if (op == 1 && lado2 == 0)
                Console.WriteLine("Error");
            if (op == 2)
                resul = Math.Sqrt(lado1 * lado1 + lado2 * lado2);
            if (op == 3 && lado1 >= lado2)
                resul = Math.Sqrt(lado1 * lado1 - lado2 * lado2);
            if (op == 3 && lado1 < lado2)
                Console.WriteLine("Error");
            if (op == 4 && lado2 >= lado1)
                resul = Math.Sqrt(lado2 * lado2 - lado1 * lado1);
            if (op == 4 && lado2 < lado1)
                Console.WriteLine("Error");
            Console.WriteLine("Valor de resultado: " + resul);
            Console.WriteLine();
            Console.Write("Presiona una tecla para terminar . . . ");
            Console.ReadKey();
        }
    }
}
