﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            //Datos de entrada
            double numero;
            Double cero = 0;

            //Datos de trabajo
            string valor;

            //Dato de salida
            double raiz;

            //Pedir que se ingrese un dato numérico
            Console.WriteLine("Ingresa un dato numérico: ");
            valor = Console.ReadLine();
            numero = Convert.ToDouble(valor);

            //Calcular la raiz
            raiz = Math.Sqrt(numero);

            //Mostrar la raiz del dato numérico ingresado
            if (numero > 0)
            {
                Console.Write("El dato ingresado es positivo, y la raiz de {0} es {1} ", numero, raiz);
            }
            if (numero < 0)
            {
                Console.Write("No existen raices pares de números negativos");
            }
            if (numero == 0)
            {
                Console.Write("El dato ingresado es igual a cero y no tiene raiz");
            }
        }
    }
}
